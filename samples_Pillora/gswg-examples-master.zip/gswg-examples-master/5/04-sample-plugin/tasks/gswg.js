module.exports = function(grunt) {

  grunt.registerTask("gswg", function() {
    grunt.log.ok("Hello, you have successfully run the 'gswg' task.");
  });

};
