var stuff = function(some, awesome, cool, code) {
  var even = 42, cooler = 7;
  return some + even + cooler + code;
};