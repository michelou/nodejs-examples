
exports.add = function(c, d) {
  return c + d;
};
