module.exports = function(grunt) {

  grunt.registerTask('foo', function() {
    console.log('foo is running...');
  });

};