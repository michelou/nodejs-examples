(function foo() {

  var aLongVariableName = 42;

  function aLongFunctionName(aLongParameterName) {
    return aLongParameterName + 21;
  }

  alert(aLongFunctionName(aLongVariableName));

})();